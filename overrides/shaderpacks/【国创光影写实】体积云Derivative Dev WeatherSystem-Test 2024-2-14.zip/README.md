# 请勿将此光影在任何国际平台传播！

[二创光影]Derivative

修改自：  SEUS Renewed v1.0.1
原作者：  Sonic Ether (Cody Darr)
二次创作：HaringPro

特别鸣谢:
qwertyuiop —— 技术支持
GeForceLegend —— 技术支持
Yi-Meng —— 宣传
factorization —— 宣传
